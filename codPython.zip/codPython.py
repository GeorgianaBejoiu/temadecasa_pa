def minimum(number_one, number_two, number_three):
    """Function to calculate the minimum of three numbers"""
    return min(number_one, number_two, number_three)

def calculate_the_minimum_number_of_operations(code_fragment, syntax_rule):
    """Function that calculates the minimum number of operations required to correct a code fragment"""
    length_code_fragment = len(code_fragment)
    length_syntax_rule = len(syntax_rule)

    two_dimensional_matrix = [[0] * (length_syntax_rule + 1) for _ in range(length_code_fragment + 1)]

    for iterator1 in range(length_code_fragment + 1):
        for iterator2 in range(length_syntax_rule + 1):
            if iterator1 == 0:
                two_dimensional_matrix[iterator1][iterator2] = iterator2
            elif iterator2 == 0:
                two_dimensional_matrix[iterator1][iterator2] = iterator1
            elif code_fragment[iterator1 - 1] == syntax_rule[iterator2 - 1]:
                two_dimensional_matrix[iterator1][iterator2] = two_dimensional_matrix[iterator1 - 1][iterator2 - 1]
            else:
                two_dimensional_matrix[iterator1][iterator2] = 1 + minimum(
                    two_dimensional_matrix[iterator1][iterator2 - 1],
                    two_dimensional_matrix[iterator1 - 1][iterator2],
                    two_dimensional_matrix[iterator1 - 1][iterator2 - 1]
                )

    return two_dimensional_matrix

def reconstruct_corrected_code(code_fragment, syntax_rule, two_dimensional_matrix):
    """Function that corrects the code fragment according to the syntax rule"""
    length_code_fragment = len(code_fragment)
    length_syntax_rule = len(syntax_rule)

    iterator1 = length_code_fragment
    iterator2 = length_syntax_rule
    corrected_code = []

    while iterator1 > 0 and iterator2 > 0:
        if code_fragment[iterator1 - 1] == syntax_rule[iterator2 - 1]:
            corrected_code.append(code_fragment[iterator1 - 1])
            iterator1 -= 1
            iterator2 -= 1
        elif two_dimensional_matrix[iterator1][iterator2] == two_dimensional_matrix[iterator1 - 1][iterator2 - 1] + 1:
            corrected_code.append(syntax_rule[iterator2 - 1])
            iterator1 -= 1
            iterator2 -= 1
        elif two_dimensional_matrix[iterator1][iterator2] == two_dimensional_matrix[iterator1 - 1][iterator2] + 1:
            iterator1 -= 1
        elif two_dimensional_matrix[iterator1][iterator2] == two_dimensional_matrix[iterator1][iterator2 - 1] + 1:
            corrected_code.append(syntax_rule[iterator2 - 1])
            iterator2 -= 1

    while iterator1 > 0:
        corrected_code.append(code_fragment[iterator1 - 1])
        iterator1 -= 1

    while iterator2 > 0:
        corrected_code.append(syntax_rule[iterator2 - 1])
        iterator2 -= 1

    corrected_code.reverse()
    return ''.join(corrected_code)

def main():
    MAX_LENGTH = 1000

    given_code = input("Enter the code fragment: ").strip()
    syntax_rule = input("Enter the syntax rule: ").strip()

    two_dimensional_matrix = calculate_the_minimum_number_of_operations(given_code, syntax_rule)
    minimum_operation = two_dimensional_matrix[len(given_code)][len(syntax_rule)]

    print(f"The minimum number of operations required is: {minimum_operation}")
    print("Corrected code fragment:")
    corrected_code = reconstruct_corrected_code(given_code, syntax_rule, two_dimensional_matrix)
    print(corrected_code)

if __name__ == "__main__":
    main()
