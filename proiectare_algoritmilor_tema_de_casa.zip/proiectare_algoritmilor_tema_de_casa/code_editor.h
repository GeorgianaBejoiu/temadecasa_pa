#ifndef CODE_EDITOR_H_INCLUDED
#define CODE_EDITOR_H_INCLUDED
int minimum(int number_one, int number_two, int number_three);
int calculate_the_minimum_number_of_operations(char *code_fragment, char *syntax_rule, int **two_dimensional_Matrix);
void reconstruct_corrected_code(char *code_fragment, char *syntax_rule, int length_code_fragment, int length_syntax_rule, int **two_dimensional_Matrix);



#endif // CODE_EDITOR_H_INCLUDED
