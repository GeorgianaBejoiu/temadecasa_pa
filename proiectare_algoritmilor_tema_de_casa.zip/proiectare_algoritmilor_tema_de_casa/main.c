#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "code_editor.h"
#define MAX_LENGTH 1000

int main()
{
    char given_code[MAX_LENGTH];//Declare the string 'given_code'
    char syntax_rule[MAX_LENGTH];//Declare the string 'syntax_rule'

    printf("Enter the code fragment:");
    fgets(given_code, MAX_LENGTH, stdin);
    given_code[strcspn(given_code, "\n")]=0;

    printf("Enter the syntax rule:");
    fgets(syntax_rule, MAX_LENGTH, stdin);
    syntax_rule[strcspn(syntax_rule, "\n")]=0;

    int length_code_fragment=strlen(given_code);//Initialize code fragment length
    int length_syntax_rule=strlen(syntax_rule);//Initialize syntax rule length

    int **two_dimensional_Matrix=(int**)malloc((length_code_fragment+1)*sizeof(int*));
    for(int iterator=0;iterator<=length_code_fragment;++iterator)
    {
        two_dimensional_Matrix[iterator]=(int*)malloc((length_syntax_rule+1)*sizeof(int));
    }
    int minimum_operation=calculate_the_minimum_number_of_operations(given_code, syntax_rule, two_dimensional_Matrix);
    printf("The minimum number of operations required is: %d\n", minimum_operation);
    printf("Corrected code fragment:\n");
    reconstruct_corrected_code(given_code, syntax_rule, length_code_fragment, length_syntax_rule, two_dimensional_Matrix);
    for(int iterator=0;iterator<=length_code_fragment;++iterator)
    {
        free(two_dimensional_Matrix[iterator]);
    }
    free(two_dimensional_Matrix);

    return 0;
}
