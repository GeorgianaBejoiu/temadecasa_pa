#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "code_editor.h"

///Funtion to caculate the minimum of three numbers
int minimum(int number_one, int number_two, int number_three) {
    int minim;//variable that will store the minimum value of three numbers
    if (number_one < number_two) {
        minim = (number_one < number_three) ? number_one : number_three;
    } else {
        minim = (number_two < number_three) ? number_two : number_three;
    }
    return minim;
}

///Function that calculate the minimum number of operations required to correct a code fragment
int calculate_the_minimum_number_of_operations(char *code_fragment, char *syntax_rule, int **two_dimensional_Matrix) {
    int length_code_fragment = strlen(code_fragment);//Calculate the length of 'code_fragment' string and store it in the 'length_code_fragment' variable
    int length_syntax_rule = strlen(syntax_rule);//Calculate the length of 'syntax_rule' string and store it in the 'length_syntax_rule' variable

    for(int iterator1=0;iterator1<=length_code_fragment;++iterator1)
    {
        two_dimensional_Matrix[iterator1]=(int*)malloc((length_syntax_rule+1)*sizeof(int));//Dynamically alocate memory for each row of the array'two_dimensional_Matrix' so that it can contain 'length_syntax_rule+1' integer elements
    }
    for (int iterator1 = 0; iterator1 <= length_code_fragment; ++iterator1) {
        for (int iterator2 = 0; iterator2 <= length_syntax_rule; ++iterator2) {
            if (iterator1 == 0) {//Chech if iterator1 is 0.If this is true, then we set the current element of the matrix to the value 'iterator2'
                two_dimensional_Matrix[iterator1][iterator2] = iterator2;
            } else if (iterator2 == 0) {//If 'iterator1' is not 0, check if 'iterator2' este 0.If is true, then  we set the current element of the matrix to the value 'iterator1'
                two_dimensional_Matrix[iterator1][iterator2] = iterator1;
            } else if (code_fragment[iterator1 - 1] == syntax_rule[iterator2 - 1]) {//If neither 'iterator1' nor 'iterator2' is 0, check that the correspomding characters in 'code_fragment' and 'syntax_rule' are equal
                two_dimensional_Matrix[iterator1][iterator2] = two_dimensional_Matrix[iterator1 - 1][iterator2 - 1];
            } else {//If characters are not equal, then set the current element ofg the matrix to 1+the minimum value of the three possible operations:insert, delete and replace
                two_dimensional_Matrix[iterator1][iterator2] = 1 + minimum(two_dimensional_Matrix[iterator1][iterator2 - 1], two_dimensional_Matrix[iterator1 - 1][iterator2], two_dimensional_Matrix[iterator1 - 1][iterator2 - 1]);
            }
        }
    }

    return two_dimensional_Matrix[length_code_fragment][length_syntax_rule];
}

///Function that corrects the code fragment according to the syntax rule
void reconstruct_corrected_code(char *code_fragment, char *syntax_rule, int length_code_fragment, int length_syntax_rule, int **two_dimensional_Matrix) {
    int iterator1 = length_code_fragment;//Intialization iterator1 with value 'length_code_fragment'
    int iterator2 = length_syntax_rule;//Intialization iterator2 with value 'length_syntax_rule'
    char *corrected_code = (char*)malloc((length_code_fragment + length_syntax_rule + 1) * sizeof(char));//Dynamically allocate memory for 'corrected_code' string that will contain the corrected code
    if (corrected_code == NULL) {//Check if the memory allocation has succeeded.If not, an error message is displayed and the program is exited
        fprintf(stderr, "Memory allocation failed.");
        exit(EXIT_FAILURE);
    }
    int index = 0;//Initialize variable 'index' with value 0 to keep the current position

    while (iterator1 > 0 && iterator2 > 0) {//It runs 'code_fragment' and 'syntax_rule' from the end to beginning as long as iterator1 and iterator2 are greater than 0.
    //1.Equals characters
        if (code_fragment[iterator1 - 1] == syntax_rule[iterator2 - 1]) {//If the current characters in 'code_fragment' and 'syntax_rule' are equal, it add them to the 'corrected_code' and decrement both iterators.
            corrected_code[index++] = code_fragment[iterator1 - 1];
            iterator1--;
            iterator2--;
    //2.Replecement
        } else if (two_dimensional_Matrix[iterator1][iterator2] == two_dimensional_Matrix[iterator1 - 1][iterator2 - 1] + 1) {//If the value in the two-dimensional array at the current position is equal to the value in the diagonal +1, we add the current characters from the 'syntax_rule' in the 'corrected_code' and decrement both iterators.
            corrected_code[index++] = syntax_rule[iterator2 - 1];
            iterator1--;
            iterator2--;
    //3.Clear
        } else if (two_dimensional_Matrix[iterator1][iterator2] == two_dimensional_Matrix[iterator1 - 1][iterator2] + 1) {//If the value in two-dimensional array at the current position is equal to the top value +1, we decrement 'iterator2'.
            iterator1--;
    //4.Insert
        } else if (two_dimensional_Matrix[iterator1][iterator2] == two_dimensional_Matrix[iterator1][iterator2 - 1] + 1) {//If the value in two-dimensional array at the current position is equal to the value on the left +1, we add the current character from 'syntax_rule' in 'corrected_code' and decrement 'iterator2'.
            corrected_code[index++] = syntax_rule[iterator2 - 1];
            iterator2--;
        }
    }

    while (iterator1 > 0) {//If there are any unprocessed characters left in the 'code_fragment', we add them to the 'corrected_code'
        corrected_code[index++] = code_fragment[--iterator1];
    }
    while (iterator2 > 0) {//{//If there are any unprocessed characters left in the 'syntax_rule', we add them to the 'corrected_code'
        corrected_code[index++] = syntax_rule[--iterator2];
    }
    corrected_code[index] = '\0';//Add the null character to the end of 'corrected_code' to end it corectly

    for (int iterator3 = 0; iterator3 < index / 2; iterator3++) {//Reverse the string 'corrected_code' because it was built from the end to the beginning
        char temp = corrected_code[iterator3];
        corrected_code[iterator3] = corrected_code[index - iterator3 - 1];
        corrected_code[index - iterator3 - 1] = temp;
    }

    printf("%s\n", corrected_code);
    free(corrected_code);
}
